# -*- coding: utf-8 -*-

from libs.utils import *

def read(item):
    itemlist = list()

    # leer la url
    data = httptools.downloadpage(item.url).data

    # recorrer uno a uno los <item> del documento
    for it in re.findall('<item>(.*?)</item>', data, re.S):

        if re.findall('<externallink>(.*?)</externallink>',it):
            # Si el <item> contiene la etiqueta <externallink>
            url = re.findall('<externallink>(.*?)</externallink>',it)[0]
            if not url: continue
            action = 'read'

        elif re.findall('<urlsolve>(.*?)</urlsolve>',it):
            # Si el <item> contiene la etiqueta <urlsolve>
            url = re.findall('<urlsolve>(.*?)</urlsolve>', it)[0]
            if not url: continue
            action = 'play'

        else:
            action = None
            url = None

        if url:
            # Formatear las urls como urls validas de youtube
            id = re.findall('https://www\.youtube\.com/watch\?v=([a-zA-Z0-9_-]{11})', url)
            if not id:
                id = re.findall('https://youtu.be/([a-zA-Z0-9_-]{11})', url)

            if id:
                t = re.findall('[\?&]t=(\d+)', url)
                url = "https://www.youtube.com/watch?v=" + id[0]
                if t:
                    url += "&t=" + t[0]


        icon = re.findall('<thumbnail>(.*?)</thumbnail>', it)
        fanart= re.findall('<fanart>(.*?)</fanart>', it)
        itemlist.append(item.clone(
            label= re.findall('<title>(.*?)</title>', it)[0],
            action= action,
            isPlayable=True if action == 'play' else False,
            url= url,
            fanart=fanart[0] if fanart else item.fanart,
            icon= icon[0] if icon else item.icon
        ))

    return itemlist


def run(item):
    #logger('run item: %s' % item, 'info')
    itemlist = list()

    # acciones especiales
    if not item.action:
        logger('Item sin acción')
        return

    if item.action == 'play':
        play(item)
        return

    # Para q Kodi cachee los itemlist o no
    cacheToDisc = False if item.action == 'read' else True

    # resto de acciones
    if item.action in globals():
        itemlist = globals()[item.action](item)

    if itemlist:
        for item in itemlist:
            listitem = xbmcgui.ListItem(item.label or item.title)
            listitem.setInfo('video', {'title': item.label or item.title, 'mediatype': 'video'})

            if item.plot:
                listitem.setInfo('video', {'plot': item.plot})
            if item.duration:
                listitem.setInfo('video', {'duration': item.duration})

            # Añadir imagenes
            for n, v in item.getart().items():
                """if item.type in ['next','buscar'] and n in ['icon','thumb','poster']:
                    v = os.path.join(IMAGE_PATH, '%s.png' % item.type)
                """
                listitem.setArt({n: v})

            if item.isPlayable or item.action == 'play':
                listitem.setProperty('IsPlayable', 'true')
                isFolder = False
                item.isPlayable = True
                xbmcplugin.setContent(int(sys.argv[1]), 'videos')

            elif isinstance(item.isFolder, bool):
                isFolder = item.isFolder

            elif not item.action:
                isFolder = False
            else:
                isFolder = True


            xbmcplugin.addDirectoryItem(
                handle=int(sys.argv[1]),
                url='%s?%s' % (sys.argv[0], item.tourl()),
                listitem=listitem,
                isFolder=isFolder,
                totalItems=len(itemlist)
            )

        xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True, cacheToDisc=cacheToDisc)


class MyPlayer(xbmc.Player):
    def __init__(self):
        self.total_Time = 0

    def playStream(self, videoUrl, listitem, init_time=0.0):
        self.AVStarted = False
        self.is_active = True
        self.init_time = float(init_time)

        monitor = xbmc.Monitor()

        self.play(videoUrl, listitem)
        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)

        while self.is_active and not monitor.abortRequested():
            monitor.waitForAbort(1)

    def onAVStarted(self):
        #logger("PLAYBACK AVSTARTED")
        self.AVStarted = True
        if self.init_time:
            self.seekTime(self.init_time)

    def onPlayBackEnded(self):
        #logger("PLAYBACK ENDED")  # Corte de red o fin del video
        self.is_active = False

    def onPlayBackStopped(self):
        #logger("PLAYBACK STOPPED")  # Parado por el usuario o no iniciado por http 429
        self.is_active = False

    def onPlayBackError(self):
        #logger("PLAYBACK ERROR")
        self.is_active = False

    def onPlayBackStarted(self):
        #logger("PLAYBACK STARTED")
        pass


def play(item):
    xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=False)
    xbmc.executebuiltin('Dialog.Close(all,true)')
    msgbox = xbmcgui.Dialog()

    # extraemos el id
    id = re.findall('v=([a-zA-Z0-9_-]{11})', item.url)[0]

    # reproduccion desde duffyou
    if ADDON.getSetting('plugin_play') == 'Plugin Duffyou':
        try:
            try:
                import duffyou
            except:
                msgbox.ok(ADDON_NAME, "Es necesario tener instalado el Plugin DuffYou para usar esta funcionalidad."
                        "[CR]Instalalo desde Luar o desde el repositorio, o bien desactiva esta opción en los ajustes")
                return
            url, title, plot, thumb = duffyou.resolver(id,item.label)
        except:
            pass

        else:
            listitem = xbmcgui.ListItem()
            listitem.setInfo('video', {'title':title, 'plot':plot})
            listitem.setArt(item.getart())
            listitem.setProperty('IsPlayable', 'true')
            listitem.setPath(url)

            if '/dash/' in url:
                # InputStream
                from inputstreamhelper import Helper

                is_helper = Helper('mpd')
                if is_helper.check_inputstream():
                    if six.PY2:
                        listitem.setProperty('inputstreamaddon', is_helper.inputstream_addon)
                    else:
                        listitem.setProperty('inputstream', is_helper.inputstream_addon)

                    listitem.setProperty('inputstream.adaptive.manifest_type','mpd')
                    listitem.setProperty('inputstream.adaptive.stream_headers',
                                         'user-agent=%s' % httptools.default_headers['User-Agent'])
                    listitem.setMimeType('application/dash+xml')
                    listitem.setContentLookup(False)

            init_time = 0.0
            t = re.findall('&t=(\d+)', item.url)
            if t:
                init_time = t[0]

            MyPlayer().playStream(url, listitem, init_time)

    else:
        # reproduccion con plugin.video.youtube
        url = 'plugin://plugin.video.youtube/play/?video_id=' + id
        xbmc.executebuiltin('RunPlugin(' + url + ')')


if __name__ == '__main__':
    if sys.argv[2]: 
        # Para skins y widgets
        patron = r'((?:&|\?)reload=.*?$)'
        sys.argv[2] = re.sub(patron,'', sys.argv[2])

    if sys.argv[2]:
        item = Item().fromurl(sys.argv[2])

    else:
        # Añadir aqui funciones q se ejecutaran cada vez q entremos en el ADDON

        # test()
        item = Item(action='read',
                    url= 'https://raw.githubusercontent.com/sotavent0/carnamaleon/master/index.xml',
                    icon=os.path.join(RUNTIME_PATH, 'icon.png'),
                    fanart=os.path.join(RUNTIME_PATH, 'fanart.jpg')
                    )

    run(item)

